import java.io.*;  
import java.net.*;  
import java.util.*; 


public class TcpRouter5 {
    
   private static ServerSocket serverSocket; 
   private static InetAddress host;
   private static final int server_PORT = 1248; 
   private static final int client_PORT = 1249;
   private static Socket clientLink = null;
   
   public static void main(String[] args)  
   {  
      System.out.println("Portlar Açılıyor");
      {  
          try  
          {  
        	  System.out.println("Router 5 Başlatılıyor");
        	  host = InetAddress.getLocalHost();  
          }  
          catch(Exception uhEx)  
          {  
              System.out.println("Host ID bulunamadı");  
              System.exit(1);  
          }  
            
      }
      try  
      {  
    	  
    	 serverSocket = new ServerSocket(server_PORT);  
         clientLink = new Socket(host,client_PORT);
         
      }  
      catch(IOException ioEx)  
      {  
         System.out.println("Yönlendirici bağlantı noktasına bağlanamıyor.");  
         System.exit(1);  
      }  
      
      handleClient();  
      
   }    
   private static String handleClient()  
   {  
      Socket serverLink = null;                         
      
      try  
      {  
    	  serverLink = serverSocket.accept();            
        
         Scanner senderInput =  
            new Scanner(serverLink.getInputStream());  
         
         PrintWriter senderOutput = new PrintWriter(serverLink.getOutputStream(), true);       
         
           String message = senderInput.nextLine(); 
           
           
           Scanner receiverInput = new Scanner(clientLink.getInputStream());      
   
           PrintWriter receiverOutput = new PrintWriter(clientLink.getOutputStream(), true);   
        
           
         while (!message.equals("Kapat")){ 
        	 
        	 if(!message.isEmpty())
        		 System.out.print("Göndericideki mesaj: "+message+"\t");
        	 
        	 receiverOutput.println(message);
        	 
        	 String str=receiverInput.nextLine();
        	 
        	 if(!str.isEmpty() && !message.isEmpty())
        		 System.out.println("Aıcıdaki mesaj: "+str);

        	 senderOutput.println(str);
        	 
        	 message = senderInput.nextLine();
       
        }  
      
         
       }  

       catch(IOException ioEx)  
       {  
           ioEx.printStackTrace();  
       }    
       finally  
       {  
          try  
          {  
             System.out.println(  
                        "\n Bağlantılar Kapatılıyor.");  
             serverLink.close(); 
             clientLink.close();
          }  
          catch(IOException ioEx)  
          {  
              System.out.println(  
                            "Bağlantı Kapatılmasında Hata");  
            System.exit(1);  
          }  
       }
	return null;  
   }  
   
}
